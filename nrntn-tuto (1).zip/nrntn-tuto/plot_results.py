#!/usr/bin/env python3
"""
plot_results.py  —  one figure from an NR-NTN-SIM time-series CSV

Plots throughput, SINR, delay and PDR over time from the CSV written by
ns3_nrntnsim_timeseries_optionD_approach5 (columns time_s, throughput_dl_mbps, ...),
marks the route changes (from the topology's window.json) as vertical lines, and
can overlay the geometric propagation delay computed by ntn_route_map.py.

Unknown column names are not a problem: without the usual columns, every numeric
column is plotted against the first one.

Example
  python3 plot_results.py --csv /results/SH3/timeseries_alt1109_pwr55.csv \
      --window /data/hypatia/sh3_paris_newyork/window.json \
      --map-timeline /maps/sh3_paris_newyork_timeline.csv \
      --out /results/SH3/sh3_timeseries.png

Requires: python3, matplotlib.
"""

import argparse
import csv
import json
import math
import sys
from pathlib import Path

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:
    sys.exit("ERROR: matplotlib is missing.  pip3 install matplotlib")

PANELS = [  # (title, unit, [candidate columns])
    ("Throughput", "Mbps", ["throughput_dl_mbps", "throughput_ul_mbps", "dl_throughput_mbps", "ul_throughput_mbps"]),
    ("SINR (DL)", "dB", ["sinr_dl_db"]),
    ("Delay", "ms", ["delay_dl_ms", "delay_ul_ms", "e2e_delay_theory_ms", "isl_delay_ms", "gsl_delay_ms", "e2e_ms"]),
    ("PDR", "", ["pdr_dl", "pdr_ul", "pdr"]),
]


def to_float(v):
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def read_csv(path):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        sys.exit("ERROR: %s is empty" % path)
    cols = {k: [to_float(r.get(k)) for r in rows] for k in rows[0].keys()}
    return cols


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--csv", required=True, help="time-series CSV written by the simulation")
    ap.add_argument("--window", help="window.json of the topology (route changes as vertical lines)")
    ap.add_argument("--map-timeline", help="<map>_timeline.csv from ntn_route_map.py (adds propagation delay)")
    ap.add_argument("--warmup", type=float, default=0.0, help="drop the first seconds (e.g. 10)")
    ap.add_argument("--out", default=None, help="PNG path (default: next to the CSV)")
    ap.add_argument("--title", default=None)
    a = ap.parse_args()

    cols = read_csv(a.csv)
    names = list(cols.keys())
    tcol = "time_s" if "time_s" in cols else names[0]
    t_all = cols[tcol]
    keep = [i for i, t in enumerate(t_all) if t is not None and t >= a.warmup]
    t = [t_all[i] for i in keep]
    print("CSV      : %s (%d rows, time column '%s', %d columns)" % (a.csv, len(t), tcol, len(names)))

    panels = []
    for title, unit, cands in PANELS:
        present = [c for c in cands if c in cols and any(cols[c][i] is not None for i in keep)]
        if present:
            panels.append((title, unit, present))
    if not panels:  # unknown format: every numeric column on its own panel
        for c in names:
            if c != tcol and any(cols[c][i] is not None for i in keep):
                panels.append((c, "", [c]))
        panels = panels[:8]

    map_t, map_d = [], []
    if a.map_timeline:
        with open(a.map_timeline, newline="") as f:
            for r in csv.DictReader(f):
                d = to_float(r.get("delay_ms"))
                if d is not None and to_float(r["t_s"]) >= a.warmup:
                    map_t.append(float(r["t_s"]))
                    map_d.append(d)

    changes = []
    if a.window:
        changes = [c["t"] for c in json.loads(Path(a.window).read_text()).get("route_changes", [])]

    fig, axes = plt.subplots(len(panels), 1, figsize=(9, 2.3 * len(panels)), sharex=True, squeeze=False)
    for ax, (title, unit, present) in zip(axes[:, 0], panels):
        for c in present:
            y = [cols[c][i] for i in keep]
            ax.plot(t, [v if v is not None else float("nan") for v in y], lw=1.1, label=c)
            vals = [v for v in y if v is not None]
            print("  %-22s mean %10.3f   min %10.3f   max %10.3f" % (c, sum(vals) / len(vals), min(vals), max(vals)))
        if title == "Delay" and map_t:
            ax.plot(map_t, map_d, lw=1.4, ls="--", color="black", label="propagation (map, TLE geometry)")
        for tc in changes:
            ax.axvline(tc, color="tab:red", lw=0.9, alpha=0.6)
        ax.set_ylabel(("%s (%s)" % (title, unit)) if unit else title)
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8, loc="best")
    axes[-1, 0].set_xlabel("time (s)" + ("   — red lines: route changes" if changes else ""))
    fig.suptitle(a.title or Path(a.csv).stem, fontsize=12)
    fig.tight_layout()
    out = Path(a.out) if a.out else Path(a.csv).with_suffix(".png")
    fig.savefig(out, dpi=150)
    print("Wrote %s" % out)


if __name__ == "__main__":
    main()
