#!/usr/bin/env python3
"""
make_constellation.py  —  build a Hypatia topology for NR-NTN-SIM in one command

What it does
  1. writes the constellation files with Hypatia's satgenpy:
       tles.txt (Walker constellation), isls.txt (+grid), ground_stations.txt,
       gsl_interfaces_info.txt, description.txt
  2. (--offset auto) scans one orbit at 1 s resolution, finds the first route change
     between the two ground stations and places the simulation window so that the
     change happens --lead seconds after t = 0
  3. generates the forwarding state (fstate) for the window at --step-ms resolution,
     renames the files so that the window starts at fstate_0.txt, and stores them as
     REAL files (no symlinks) next to the constellation files
  4. writes window.json (offset, step, detected route changes) — read automatically
     by ntn_route_map.py — and prints the exact ns-3 and map commands to run next

Requires: Hypatia's satgenpy (/opt/hypatia/satgenpy in the nr-ntn-sim image) and the
Python packages numpy, astropy, ephem, networkx, sgp4, geopy.
(post_analysis, cartopy, statsmodels and exputil are NOT needed.)

Example (SH3-like Paris -> New York, 66 satellites)
  python3 make_constellation.py --out /data/hypatia --name sh3_paris_newyork \
      --gs "Paris:48.8566:2.3522,New-York:40.7128:-74.0060"

Author: NR-NTN-SIM (J. Ben Abed) — Apache-2.0
"""

import argparse
import json
import math
import multiprocessing as mp
import os
import shutil
import sys
import time
import types
from pathlib import Path

MU_KM3_S2 = 398600.4418
R_EARTH_KM = 6378.135          # WGS72 equatorial radius, as used by satgenpy/sgp4
SAT_ALGO = "algorithm_free_one_only_over_isls"
SATGEN = None


# ─────────────────────────────────────────────────────────────────────────────
# satgenpy import without its plotting/statistics part
# ─────────────────────────────────────────────────────────────────────────────

def load_satgen(hypatia_dir):
    global SATGEN
    if SATGEN is not None:
        return SATGEN
    sys.path.insert(0, str(Path(hypatia_dir) / "satgenpy"))
    # post_analysis pulls cartopy/statsmodels/matplotlib: not needed to generate states
    sys.modules.setdefault("satgen.post_analysis", types.ModuleType("satgen.post_analysis"))
    try:
        import exputil  # noqa: F401
    except ImportError:
        shim = types.ModuleType("exputil")

        def _pos_int(s):
            v = int(s)
            if v < 0:
                raise ValueError("Value must be >= 0: %s" % s)
            return v

        def _pos_float(s):
            v = float(s)
            if v < 0:
                raise ValueError("Value must be >= 0: %s" % s)
            return v
        shim.parse_positive_int, shim.parse_positive_float = _pos_int, _pos_float
        sys.modules["exputil"] = shim
    try:
        import satgen
    except ImportError as e:
        sys.exit("ERROR: cannot import satgenpy (%s).\n"
                 "Install the missing package (pip3 install sgp4 geopy astropy ephem networkx numpy)\n"
                 "or check --hypatia (folder that contains satgenpy/)." % e)
    SATGEN = satgen
    return satgen


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def altitude_from_mean_motion(n_rev_day):
    n = n_rev_day * 2 * math.pi / 86400.0
    return (MU_KM3_S2 / n ** 2) ** (1.0 / 3.0) - R_EARTH_KM


def mean_motion_from_altitude(h_km):
    a = R_EARTH_KM + h_km
    return math.sqrt(MU_KM3_S2 / a ** 3) * 86400.0 / (2 * math.pi)


def max_gsl_km(h_km, min_elev_deg):
    e = math.radians(min_elev_deg)
    r, R = R_EARTH_KM + h_km, R_EARTH_KM
    return math.sqrt(r * r - (R * math.cos(e)) ** 2) - R * math.sin(e)


def tle_checksum(line):
    return sum(int(c) if c.isdigit() else (1 if c == "-" else 0) for c in line) % 10


def write_tles(path, name, n_orb, n_per, inc, mean_motion, epoch_field, phase_diff=True):
    """Same layout and RAAN/phasing as satgenpy.generate_tles_from_scratch_manual,
    but with a configurable epoch (satgenpy hard-codes 2000-01-01)."""
    with open(path, "w") as f:
        f.write("%d %d\n" % (n_orb, n_per))
        k = 0
        for orb in range(n_orb):
            raan = orb * 360.0 / n_orb
            shift = 360.0 / (n_per * 2.0) if (orb % 2 == 1 and phase_diff) else 0.0
            for n in range(n_per):
                ma = shift + n * 360.0 / n_per
                l1 = "1 %05dU 00000ABC %s  .00000000  00000-0  00000+0 0    0" % (k + 1, epoch_field)
                l2 = "2 %05d %s %s %s %s %s %s    0" % (
                    k + 1, ("%3.4f" % inc).rjust(8), ("%3.4f" % raan).rjust(8),
                    ("%0.7f" % 0.0000001)[2:], ("%3.4f" % 0.0).rjust(8),
                    ("%3.4f" % ma).rjust(8), ("%2.8f" % mean_motion).rjust(11))
                f.write("%s %d\n%s%d\n%s%d\n" % (name, k, l1, tle_checksum(l1), l2, tle_checksum(l2)))
                k += 1


def parse_gs(spec):
    out = []
    for i, item in enumerate(spec.split(",")):
        p = item.strip().split(":")
        if len(p) != 3:
            sys.exit("ERROR: --gs items must be NAME:LAT:LON, got '%s'" % item)
        out.append((i, p[0], float(p[1]), float(p[2])))
    return out


def _worker(args):
    (hyp, topo, out_dir, start_ns, end_ns, step_ns, gsl_m, isl_m) = args
    sg = load_satgen(hyp)
    import io
    import contextlib
    tl = sg.read_tles(str(topo / "tles.txt"))
    gs = sg.read_ground_stations_extended(str(topo / "ground_stations.txt"))
    isls = sg.read_isls(str(topo / "isls.txt"), len(tl["satellites"]))
    gif = sg.read_gsl_interfaces_info(str(topo / "gsl_interfaces_info.txt"), len(tl["satellites"]), len(gs))
    with contextlib.redirect_stdout(io.StringIO()):
        sg.generate_dynamic_state(str(out_dir), tl["epoch"], end_ns, step_ns, start_ns,
                                  tl["satellites"], gs, isls, gif, gsl_m, isl_m, SAT_ALGO, False)
    return start_ns


def generate_states(hyp, topo, out_dir, start_s, duration_s, step_ms, gsl_m, isl_m, procs):
    """Generate fstates for [start, start+duration] (both ends included), in parallel chunks."""
    out_dir.mkdir(parents=True, exist_ok=True)
    step_ns = int(step_ms * 1e6)
    start_ns = int(round(start_s * 1e9))
    n_steps = int(round(duration_s * 1000 / step_ms)) + 1
    procs = max(1, min(procs, n_steps // 20))
    per = math.ceil(n_steps / procs)
    jobs = []
    for i in range(procs):
        a = i * per
        b = min(n_steps, (i + 1) * per)
        if a < b:
            jobs.append((hyp, topo, out_dir, start_ns + a * step_ns, start_ns + b * step_ns,
                         step_ns, gsl_m, isl_m))
    with mp.Pool(len(jobs)) as pool:
        for _ in pool.imap_unordered(_worker, jobs):
            pass


def read_routes(fstate_dir, src, dst, n_sats):
    """Replay fstate deltas; return list of (t_s, path or None)."""
    files = []
    for p in Path(fstate_dir).glob("fstate_*.txt"):
        tag = p.stem.split("_", 1)[1]
        if tag.isdigit():
            files.append((int(tag), p))
    files.sort()
    table, out = {}, []
    for ns, p in files:
        with open(p) as f:
            for line in f:
                v = line.strip().split(",")
                if len(v) >= 3:
                    table[(int(v[0]), int(v[1]))] = int(v[2])
        path, cur, seen, ok = [], src, set(), True
        while cur != dst:
            if cur in seen:
                ok = False
                break
            seen.add(cur)
            nh = table.get((cur, dst), -1)
            if nh < 0 or (nh >= n_sats and nh != dst):
                ok = False
                break
            if nh < n_sats:
                path.append(nh)
            cur = nh
        out.append((ns / 1e9, path if ok else None))
    return out


def switches(routes):
    sw, last = [], None
    for t, p in routes:
        if p is None:
            continue
        if last is not None and p != last:
            sw.append({"t": round(t, 3), "from": last, "to": p})
        last = p
    return sw


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_argument_group("output")
    g.add_argument("--out", required=True, help="parent folder, e.g. /data/hypatia")
    g.add_argument("--name", required=True, help="topology folder name, e.g. sh3_paris_newyork")
    g.add_argument("--hypatia", default="/opt/hypatia", help="Hypatia folder containing satgenpy/ (default /opt/hypatia)")
    g.add_argument("--force", action="store_true", help="overwrite an existing folder")
    c = ap.add_argument_group("constellation")
    c.add_argument("--orbits", type=int, default=6)
    c.add_argument("--sats-per-orbit", type=int, default=11)
    c.add_argument("--inclination", type=float, default=87.9, help="degrees")
    c.add_argument("--mean-motion", type=float, default=13.40, help="rev/day (13.40 = ~1,120 km)")
    c.add_argument("--altitude-km", type=float, help="alternative to --mean-motion")
    c.add_argument("--tle-epoch", default="26106.00000000", help="TLE epoch yyddd.ffffffff (26106 = 16 Apr 2026)")
    c.add_argument("--gs", default="Paris:48.8566:2.3522,New-York:40.7128:-74.0060",
                   help="ground stations NAME:LAT:LON,... (first = source, second = destination)")
    c.add_argument("--min-elev", type=float, default=10.0, help="minimum elevation (deg) for ground links")
    c.add_argument("--max-gsl-km", type=float, help="override the ground-link range computed from --min-elev")
    c.add_argument("--max-isl-km", type=float, default=10000.0, help="max ISL length (a +grid polar ISL can reach ~7,200 km)")
    w = ap.add_argument_group("simulation window")
    w.add_argument("--duration", type=float, default=400.0, help="window length (s), = --simTime")
    w.add_argument("--step-ms", type=float, default=100.0, help="fstate resolution (ms)")
    w.add_argument("--offset", default="auto", help="'auto' or seconds after the TLE epoch where t=0 starts")
    w.add_argument("--lead", type=float, default=100.0, help="auto: the first route change lands at t ~ lead")
    w.add_argument("--scan-horizon", type=float, default=7200.0, help="auto: how far to look for a route change (s)")
    w.add_argument("--procs", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    a = ap.parse_args()

    t_start = time.time()
    sg = load_satgen(a.hypatia)
    topo = Path(a.out) / a.name
    if topo.exists():
        if not a.force:
            sys.exit("ERROR: %s already exists (use --force to overwrite)" % topo)
        shutil.rmtree(topo)
    topo.mkdir(parents=True)

    # 1. Constellation files ------------------------------------------------------
    mm = mean_motion_from_altitude(a.altitude_km) if a.altitude_km else a.mean_motion
    h_km = altitude_from_mean_motion(mm)
    n_sats = a.orbits * a.sats_per_orbit
    gsl_km = a.max_gsl_km if a.max_gsl_km else max_gsl_km(h_km, a.min_elev)
    gs = parse_gs(a.gs)
    if len(gs) < 2:
        sys.exit("ERROR: --gs needs at least two ground stations")

    write_tles(topo / "tles.txt", "NRNTN", a.orbits, a.sats_per_orbit, a.inclination, mm, a.tle_epoch)
    sg.generate_plus_grid_isls(str(topo / "isls.txt"), a.orbits, a.sats_per_orbit, isl_shift=0, idx_offset=0)
    with open(topo / "ground_stations_basic.txt", "w") as f:
        for gid, name, lat, lon in gs:
            f.write("%d,%s,%.6f,%.6f,0.0\n" % (gid, name, lat, lon))
    sg.extend_ground_stations(str(topo / "ground_stations_basic.txt"), str(topo / "ground_stations.txt"))
    sg.generate_simple_gsl_interfaces_info(str(topo / "gsl_interfaces_info.txt"), n_sats, len(gs), 1, 1, 1, 1)
    sg.generate_description(str(topo / "description.txt"), gsl_km * 1000, a.max_isl_km * 1000)

    src, dst = n_sats + gs[0][0], n_sats + gs[1][0]
    print("Constellation : %d orbits x %d sats = %d satellites, inc %.1f deg, %.4f rev/day (~%.0f km)"
          % (a.orbits, a.sats_per_orbit, n_sats, a.inclination, mm, h_km))
    print("Ground links  : max %.0f km (min elevation %.1f deg)%s"
          % (gsl_km, a.min_elev, "  [overridden]" if a.max_gsl_km else ""))
    print("Route         : %s (node %d) -> %s (node %d)" % (gs[0][1], src, gs[1][1], dst))

    # 2. Window placement ---------------------------------------------------------
    if a.offset == "auto":
        print("\n[1/2] Scanning %.0f s at 1 s to find the first route change ..." % a.scan_horizon)
        scan = topo / "_scan"
        generate_states(a.hypatia, topo, scan, 0.0, a.scan_horizon, 1000.0,
                        gsl_km * 1000, a.max_isl_km * 1000, a.procs)
        routes = read_routes(scan, src, dst, n_sats)
        shutil.rmtree(scan)
        if not any(p for _, p in routes):
            sys.exit("ERROR: no route %s -> %s at all. Lower --min-elev or check the ground stations."
                     % (gs[0][1], gs[1][1]))
        sw = [s for s in switches(routes) if s["t"] >= a.lead]
        if not sw:
            sys.exit("ERROR: no route change within %.0f s. Increase --scan-horizon." % a.scan_horizon)
        offset = max(0.0, math.floor(sw[0]["t"]) - a.lead)
        print("      first route change at %.0f s after the epoch -> window offset %.0f s" % (sw[0]["t"], offset))
    else:
        offset = float(a.offset)

    # 3. Forwarding state for the window --------------------------------------------
    print("[%s] Generating %.0f s of forwarding state at %g ms ..." %
          ("2/2" if a.offset == "auto" else "1/1", a.duration, a.step_ms))
    raw = topo / "_raw"
    generate_states(a.hypatia, topo, raw, offset, a.duration, a.step_ms,
                    gsl_km * 1000, a.max_isl_km * 1000, a.procs)
    off_ns = int(round(offset * 1e9))
    n_files = 0
    for p in raw.glob("fstate_*.txt"):
        ns = int(p.stem.split("_", 1)[1])
        p.rename(topo / ("fstate_%d.txt" % (ns - off_ns)))
        n_files += 1
    shutil.rmtree(raw)

    routes = read_routes(topo, src, dst, n_sats)
    sw = switches(routes)
    broken = sum(1 for _, p in routes if p is None)
    info = {
        "offset_s": offset, "duration_s": a.duration, "step_ms": a.step_ms, "tle_epoch": a.tle_epoch,
        "orbits": a.orbits, "sats_per_orbit": a.sats_per_orbit, "inclination_deg": a.inclination,
        "mean_motion_rev_day": mm, "altitude_km": round(h_km, 1),
        "max_gsl_km": round(gsl_km, 1), "min_elev_deg": a.min_elev, "max_isl_km": a.max_isl_km,
        "ground_stations": [{"node": n_sats + gid, "name": n, "lat": la, "lon": lo} for gid, n, la, lo in gs],
        "src_node": src, "dst_node": dst, "algorithm": SAT_ALGO,
        "route_changes": sw, "steps_without_route": broken,
    }
    (topo / "window.json").write_text(json.dumps(info, indent=2))

    # 4. Summary -------------------------------------------------------------------
    print("\nDone in %.0f s  ->  %s" % (time.time() - t_start, topo))
    print("  %d fstate files (fstate_0.txt = t 0 = %.0f s after the epoch), window.json" % (n_files, offset))
    first = next((p for _, p in routes if p), None)
    print("  route at t=0  : %s  (%d ISL hops)" % (first, len(first) - 1 if first else -1))
    if sw:
        print("  route changes :")
        for s in sw:
            print("    t = %7.1f s   %d -> %d ISL hops   %s" % (s["t"], len(s["from"]) - 1, len(s["to"]) - 1, s["to"]))
    else:
        print("  route changes : none in the window")
    if broken:
        print("  WARNING: %d time steps without a route (no satellite in view)." % broken)
    print("\nNext:\n  ns-3 : --hypatiaDir=%s/  --simTime=%g  (--satAlt=%.0f matches this altitude)"
          % (topo, a.duration, h_km))
    print("  map  : python3 ntn_route_map.py --fstate-dir %s --out <maps>/%s.html" % (topo, a.name))


if __name__ == "__main__":
    mp.set_start_method("fork", force=True)
    main()
