#!/usr/bin/env python3
"""
ntn_route_map.py  —  NR-NTN-SIM / Hypatia route map on a 3D globe (Cesium)

Reads a Hypatia topology (tles.txt, isls.txt, ground_stations.txt) and the
forwarding-state files (fstate_<ns>.txt) used by an NR-NTN-SIM run, then:

  1. replays the fstate deltas in time order (fstate_0 is complete, every later
     file only lists the entries that changed),
  2. traces the GS->GS route at every time step and detects path switches,
  3. recomputes each route's one-way propagation delay with the same geometry
     Hypatia uses (ephem ranges from the TLEs),
  4. writes one self-contained HTML page: the constellation on a 3D globe, the
     active route per phase (buttons to switch phase), and a delay timeline,
     plus two CSV files (timeline + phases).

Only dependency: python3 + ephem  (both present in the nr-ntn-sim:full image).

Examples
  # SH3 Paris -> New York, fstates shifted by 3083 s (the "switch100" folder)
  python3 ntn_route_map.py \
      --fstate-dir /data/hypatia/demo_66sat_paris_newyork_switch100 \
      --topo-dir   /data/hypatia/demo_66sat_paris_newyork \
      --offset 3083 --t-end 400 --out /maps/SH3_paris_newyork.html

  # Force the four instants reported in the paper instead of auto-detection
  python3 ntn_route_map.py ... --times 0,167.8,288.1,396.2

Author: NR-NTN-SIM (J. Ben Abed) — Apache-2.0
"""

import argparse
import csv
import json
import math
import sys
from pathlib import Path

try:
    import ephem
except ImportError:
    sys.exit("ERROR: the 'ephem' package is missing.  pip install ephem")

C_M_PER_S = 299_792_458.0


# ─────────────────────────────────────────────────────────────────────────────
# Topology input
# ─────────────────────────────────────────────────────────────────────────────

def find_file(name, dirs):
    for d in dirs:
        if d and (Path(d) / name).is_file():
            return Path(d) / name
    return None


def read_tles(path):
    """Hypatia tles.txt: '<n_orbits> <n_sats_per_orbit>' then 3 lines per satellite."""
    with open(path) as f:
        lines = [l.rstrip("\n") for l in f if l.strip()]
    sats, epoch = [], None
    for k in range(1, len(lines), 3):
        name, l1, l2 = lines[k], lines[k + 1], lines[k + 2]
        sats.append(ephem.readtle(name, l1, l2))
        yy, ddd = l1[18:20], float(l1[20:32])
        e = ephem.Date("20%s/01/01 00:00:00" % yy) + (ddd - 1.0)
        epoch = e if epoch is None else epoch
    return sats, ephem.Date(epoch)


def tle_checksum(line):
    s = 0
    for ch in line:
        if ch.isdigit():
            s += int(ch)
        elif ch == "-":
            s += 1
    return s % 10


def walker_tles(n_orb, n_per, inc, mean_motion, epoch_field):
    """Same TLEs as satgenpy.generate_tles_from_scratch_manual (fallback only)."""
    sats, k = [], 0
    for orb in range(n_orb):
        raan = orb * 360.0 / n_orb
        shift = 360.0 / (n_per * 2.0) if orb % 2 == 1 else 0.0
        for n in range(n_per):
            ma = shift + n * 360.0 / n_per
            l1 = "1 %05dU 00000ABC %s  .00000000  00000-0  00000+0 0    0" % (k + 1, epoch_field)
            l2 = "2 %05d %s %s %s %s %s %s    0" % (
                k + 1, ("%3.4f" % inc).rjust(8), ("%3.4f" % raan).rjust(8),
                ("%0.7f" % 0.0000001)[2:], ("%3.4f" % 0.0).rjust(8),
                ("%3.4f" % ma).rjust(8), ("%2.8f" % mean_motion).rjust(11))
            l1 += str(tle_checksum(l1))
            l2 += str(tle_checksum(l2))
            sats.append(ephem.readtle("Sat %d" % k, l1, l2))
            k += 1
    yy, ddd = epoch_field[0:2], float(epoch_field[2:])
    return sats, ephem.Date(ephem.Date("20%s/01/01 00:00:00" % yy) + (ddd - 1.0))


def read_isls(path):
    out = []
    if path is None:
        return out
    with open(path) as f:
        for line in f:
            p = line.split()
            if len(p) >= 2:
                out.append((int(p[0]), int(p[1])))
    return out


def read_ground_stations(path):
    """Basic (5 fields) or extended (8 fields) Hypatia format: gid,name,lat,lon,elev[,x,y,z]."""
    gs = []
    if path is None:
        return gs
    with open(path) as f:
        for line in f:
            p = [x.strip() for x in line.strip().split(",")]
            if len(p) >= 5:
                gs.append({"gid": int(p[0]), "name": p[1], "lat": float(p[2]),
                           "lon": float(p[3]), "elev": float(p[4])})
    return gs


# ─────────────────────────────────────────────────────────────────────────────
# Forwarding state replay
# ─────────────────────────────────────────────────────────────────────────────

def list_fstates(fdir):
    files = []
    for p in Path(fdir).glob("fstate_*.txt"):
        tag = p.stem.split("_", 1)[1]
        if tag.isdigit():
            files.append((int(tag), p))
    files.sort(key=lambda x: x[0])
    return files


def apply_fstate(table, path):
    with open(path) as f:
        for line in f:
            p = line.strip().split(",")
            if len(p) >= 3:
                try:
                    table[(int(p[0]), int(p[1]))] = int(p[2])
                except ValueError:
                    pass


def trace(table, src, dst, n_sats):
    """Return (list_of_satellite_ids, status) with status in ok / loop / broken."""
    path, cur, seen = [], src, set()
    while cur != dst:
        if cur in seen:
            return path, "loop"
        seen.add(cur)
        nh = table.get((cur, dst))
        if nh is None or nh < 0:
            return path, "broken"
        if nh < n_sats:
            path.append(nh)
        elif nh != dst:
            return path, "broken"     # relays through another GS: not expected here
        cur = nh
    return path, "ok"


# ─────────────────────────────────────────────────────────────────────────────
# Geometry (same method as Hypatia's distance_tools)
# ─────────────────────────────────────────────────────────────────────────────

class Geo:
    def __init__(self, sats, epoch, offset_s, gs_src, gs_dst):
        self.sats, self.epoch, self.offset = sats, epoch, offset_s
        self.src, self.dst = gs_src, gs_dst

    def date(self, t):
        return ephem.Date(self.epoch + (t + self.offset) / 86400.0)

    def _obs(self, t, lat="0", lon="0", elev=0.0):
        o = ephem.Observer()
        o.epoch = self.epoch
        o.date = self.date(t)
        o.lat, o.lon, o.elevation = lat, lon, elev
        return o

    def gsl(self, t, gs, sid):
        """(distance_m, elevation_angle_deg) ground station -> satellite."""
        o = self._obs(t, str(gs["lat"]), str(gs["lon"]), gs["elev"])
        s = self.sats[sid]
        s.compute(o)
        return s.range, math.degrees(s.alt)

    def isl(self, t, a, b):
        o = self._obs(t)
        s1, s2 = self.sats[a], self.sats[b]
        s1.compute(o)
        r1 = s1.range
        s2.compute(o)
        r2 = s2.range
        ang = float(repr(ephem.separation(s1, s2)))
        return math.sqrt(max(r1 * r1 + r2 * r2 - 2 * r1 * r2 * math.cos(ang), 0.0))

    def route(self, t, path):
        """One-way propagation delay (ms) and GSL elevation angles (deg)."""
        if not path:
            return float("nan"), float("nan"), float("nan")
        d1, el1 = self.gsl(t, self.src, path[0])
        d2, el2 = self.gsl(t, self.dst, path[-1])
        d = d1 + d2 + sum(self.isl(t, path[k], path[k + 1]) for k in range(len(path) - 1))
        return d / C_M_PER_S * 1e3, el1, el2

    def positions(self, t):
        d = self.date(t)
        out = []
        for s in self.sats:
            s.compute(d)
            out.append([round(math.degrees(s.sublong), 4),
                        round(math.degrees(s.sublat), 4),
                        round(float(s.elevation), 0)])
        return out


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def pick_gs(gs_list, key, n_sats, default_idx):
    if key is None:
        return gs_list[default_idx]
    for g in gs_list:
        if g["name"].lower() == str(key).lower():
            return g
    if str(key).isdigit():
        k = int(key)
        gid = k - n_sats if k >= n_sats else k
        for g in gs_list:
            if g["gid"] == gid:
                return g
    sys.exit("ERROR: ground station '%s' not found in ground_stations.txt (%s)"
             % (key, ", ".join(g["name"] for g in gs_list)))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--fstate-dir", required=True, help="folder holding fstate_<ns>.txt (the one passed to --hypatiaDir)")
    ap.add_argument("--topo-dir", help="folder with tles.txt / isls.txt / ground_stations.txt (default: fstate dir, then its parent)")
    ap.add_argument("--offset", type=float, default=None,
                    help="seconds between the TLE epoch and fstate t=0 (default: window.json if present, "
                         "else 0; use 3083 for the old *_switch100 folder)")
    ap.add_argument("--src", help="source GS name or node id (default: first GS)")
    ap.add_argument("--dst", help="destination GS name or node id (default: second GS)")
    ap.add_argument("--t-start", type=float, default=0.0)
    ap.add_argument("--t-end", type=float, default=None)
    ap.add_argument("--times", help="comma-separated instants (s) to show instead of auto-detected switches")
    ap.add_argument("--min-duration", type=float, default=0.0, help="hide phases shorter than this (s)")
    ap.add_argument("--walker", help="fallback when tles.txt is missing: ORBITS,SATS_PER_ORBIT,INC_DEG,MEAN_MOTION")
    ap.add_argument("--tle-epoch", default="00001.00000000", help="fallback TLE epoch field yyddd.ffffffff")
    ap.add_argument("--out", default="route_map.html")
    ap.add_argument("--title", default=None)
    a = ap.parse_args()

    fdir = Path(a.fstate_dir)
    search = [a.topo_dir, fdir, fdir.parent]

    # Window offset: explicit > window.json (written by make_constellation.py) > 0
    wj = fdir / "window.json"
    if wj.is_file():
        w_off = float(json.loads(wj.read_text()).get("offset_s", 0.0))
        if a.offset is None:
            a.offset = w_off
            print("Offset        : %.1f s (from window.json)" % w_off)
        elif abs(a.offset - w_off) > 1e-6:
            print("WARNING: --offset %.1f differs from window.json (%.1f); using --offset." % (a.offset, w_off))
    if a.offset is None:
        a.offset = 0.0

    # Constellation
    tles = find_file("tles.txt", search)
    if tles:
        sats, epoch = read_tles(tles)
        print("TLEs          : %s (%d satellites, epoch %s)" % (tles, len(sats), epoch))
    elif a.walker:
        no, ns, inc, mm = a.walker.split(",")
        sats, epoch = walker_tles(int(no), int(ns), float(inc), float(mm), a.tle_epoch)
        print("TLEs          : regenerated from --walker %s (epoch field %s)" % (a.walker, a.tle_epoch))
    else:
        sys.exit("ERROR: tles.txt not found in %s.\n"
                 "Point --topo-dir to the folder Hypatia generated (it holds tles.txt), "
                 "or pass --walker 6,11,87.9,13.40 --tle-epoch <yyddd.ffffffff>." % [str(d) for d in search if d])
    n_sats = len(sats)

    isls = read_isls(find_file("isls.txt", search))
    gs_list = read_ground_stations(find_file("ground_stations.txt", search))
    if len(gs_list) < 2:
        sys.exit("ERROR: ground_stations.txt not found or has fewer than 2 stations.")
    src = pick_gs(gs_list, a.src, n_sats, 0)
    dst = pick_gs(gs_list, a.dst, n_sats, 1)
    src_id, dst_id = n_sats + src["gid"], n_sats + dst["gid"]
    print("Route         : %s (node %d) -> %s (node %d)" % (src["name"], src_id, dst["name"], dst_id))
    print("ISLs          : %d links" % len(isls))

    geo = Geo(sats, epoch, a.offset, src, dst)
    alt0 = [p[2] for p in geo.positions(0.0)]
    mean_alt_km = sum(alt0) / len(alt0) / 1000.0
    print("Mean altitude : %.0f km (from the TLEs, at t=0)" % mean_alt_km)

    # Replay fstates
    files = list_fstates(fdir)
    if not files:
        sys.exit("ERROR: no fstate_*.txt in %s" % fdir)
    broken = [p for _, p in files if not p.exists()]
    if broken:
        sys.exit("ERROR: %d of %d fstate files are broken symlinks (e.g. %s -> %s).\n"
                 "This folder was built with absolute symlinks. Re-archive it with dereferencing:\n"
                 "  tar czhf hypatia_data.tar.gz <folders>      (note the 'h')\n"
                 "or make a real copy first:  cp -rL <folder> <folder>_real"
                 % (len(broken), len(files), broken[0].name, broken[0].readlink()))
    t_end = a.t_end if a.t_end is not None else files[-1][0] / 1e9
    step = (files[1][0] - files[0][0]) / 1e9 if len(files) > 1 else 0.0
    print("fstates       : %d files, step %.3f s, window %.1f-%.1f s, offset %.1f s"
          % (len(files), step, a.t_start, t_end, a.offset))

    table, timeline, phases = {}, [], []
    last_ok, transient = None, 0
    for ns, p in files:
        t = ns / 1e9
        apply_fstate(table, p)
        if t < a.t_start:
            continue
        if t > t_end:
            break
        path, status = trace(table, src_id, dst_id, n_sats)
        if status != "ok":
            transient += 1
            timeline.append({"t": t, "status": status, "hops": None, "delay_ms": None, "path": path})
            continue
        delay, el1, el2 = geo.route(t, path)
        timeline.append({"t": t, "status": "ok", "hops": len(path) - 1, "delay_ms": delay,
                         "el_src": el1, "el_dst": el2, "path": path})
        if path != last_ok:
            phases.append({"t": t, "path": path})
            last_ok = path

    for i, ph in enumerate(phases):
        ph["t_end"] = phases[i + 1]["t"] if i + 1 < len(phases) else t_end

    # Explicit instants instead of auto-detection
    if a.times:
        wanted = [float(x) for x in a.times.split(",")]
        ok_steps = [r for r in timeline if r["status"] == "ok"]
        phases = []
        for tw in wanted:
            r = min(ok_steps, key=lambda r: abs(r["t"] - tw))
            phases.append({"t": r["t"], "t_end": r["t"], "path": r["path"]})

    phases = [ph for ph in phases if (ph["t_end"] - ph["t"]) >= a.min_duration or a.times]
    if not phases:
        sys.exit("ERROR: no valid route found in the window.")

    isl_set = {(min(x, y), max(x, y)) for x, y in isls}
    print("\n  #   t_start    t_end   ISL hops  delay[ms]  elev src/dst[deg]  satellites")
    for i, ph in enumerate(phases):
        delay, el1, el2 = geo.route(ph["t"], ph["path"])
        ph.update({"hops": len(ph["path"]) - 1, "delay_ms": round(delay, 2),
                   "el_src": round(el1, 1), "el_dst": round(el2, 1),
                   "sats": geo.positions(ph["t"])})
        bad = [(ph["path"][k], ph["path"][k + 1]) for k in range(len(ph["path"]) - 1)
               if isl_set and (min(ph["path"][k], ph["path"][k + 1]),
                               max(ph["path"][k], ph["path"][k + 1])) not in isl_set]
        flag = ""
        if el1 < 0 or el2 < 0:
            flag += "  <-- GSL below horizon: check --offset / max_gsl_length"
        if bad:
            flag += "  <-- hop not in isls.txt: %s" % bad
        ph["warning"] = flag.strip(" <-")
        print("  %-2d %8.1f %8.1f   %6d   %8.2f      %6.1f / %-6.1f   %s%s"
              % (i + 1, ph["t"], ph["t_end"], ph["hops"], delay, el1, el2, ph["path"], flag))
    if transient:
        print("\n  %d time step(s) had no clean route (loop or missing entry) and were skipped." % transient)

    # Outputs
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out.with_name(out.stem + "_timeline.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t_s", "status", "isl_hops", "delay_ms", "elev_src_deg", "elev_dst_deg", "path"])
        for r in timeline:
            w.writerow([round(r["t"], 3), r["status"], r["hops"],
                        "" if r["delay_ms"] is None else round(r["delay_ms"], 3),
                        "" if r.get("el_src") is None else round(r["el_src"], 2),
                        "" if r.get("el_dst") is None else round(r["el_dst"], 2),
                        " ".join(map(str, r["path"]))])
    with open(out.with_name(out.stem + "_phases.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["phase", "t_start_s", "t_end_s", "isl_hops", "delay_ms", "elev_src_deg", "elev_dst_deg", "path"])
        for i, ph in enumerate(phases):
            w.writerow([i + 1, round(ph["t"], 3), round(ph["t_end"], 3), ph["hops"], ph["delay_ms"],
                        ph["el_src"], ph["el_dst"], " ".join(map(str, ph["path"]))])

    # Thin the timeline for the page (<= 1500 points)
    ok = [r for r in timeline if r["status"] == "ok"]
    stride = max(1, len(ok) // 1500)
    tl = {"t": [round(r["t"], 2) for r in ok[::stride]],
          "d": [round(r["delay_ms"], 3) for r in ok[::stride]]}

    data = {
        "title": a.title or "%s → %s" % (src["name"], dst["name"]),
        "src": {"name": src["name"], "lat": src["lat"], "lon": src["lon"]},
        "dst": {"name": dst["name"], "lat": dst["lat"], "lon": dst["lon"]},
        "isls": [list(x) for x in isls],
        "phases": [{k: ph[k] for k in ("t", "t_end", "path", "hops", "delay_ms",
                                         "el_src", "el_dst", "sats", "warning")} for ph in phases],
        "timeline": tl,
        "meta": {"n_sats": n_sats, "mean_alt_km": round(mean_alt_km), "offset": a.offset,
                 "step": step, "t_end": t_end, "fstate_dir": str(fdir)},
    }
    html = HTML_TEMPLATE.replace("__DATA__", json.dumps(data, separators=(",", ":")))
    html = html.replace("__TITLE__", data["title"])
    out.write_text(html, encoding="utf-8")
    print("\nWrote %s  (+ _timeline.csv, _phases.csv)" % out)
    print("View it:  cd %s && python3 -m http.server 8080   then open http://localhost:8080/%s"
          % (out.parent.resolve(), out.name))


HTML_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__ — NR-NTN-SIM route map</title>
<script src="https://cesium.com/downloads/cesiumjs/releases/1.114/Build/Cesium/Cesium.js"></script>
<link href="https://cesium.com/downloads/cesiumjs/releases/1.114/Build/Cesium/Widgets/widgets.css" rel="stylesheet">
<style>
  html, body, #globe { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; background: #000; }
  #panel { position: absolute; top: 12px; left: 12px; width: 330px; max-height: calc(100% - 24px); overflow: auto;
           background: rgba(16,20,28,.88); color: #e8ecf2; font: 13px/1.4 system-ui, sans-serif;
           border-radius: 10px; padding: 14px; box-sizing: border-box; }
  #panel h1 { font-size: 16px; margin: 0 0 2px; }
  #panel .sub { color: #9aa6b8; font-size: 12px; margin-bottom: 10px; }
  .ph { display: block; width: 100%; text-align: left; border: 1px solid #2c3546; background: #1a2130;
        color: inherit; border-radius: 7px; padding: 7px 9px; margin: 0 0 6px; cursor: pointer; font: inherit; }
  .ph.on { border-color: var(--c); box-shadow: inset 4px 0 0 var(--c); background: #222b3d; }
  .ph b { font-weight: 600; }
  .ph .w { color: #ffb454; font-size: 11px; }
  #chart { margin-top: 8px; }
  .legend { color: #9aa6b8; font-size: 11px; margin-top: 8px; }
  .legend i { display: inline-block; width: 18px; height: 3px; vertical-align: middle; margin-right: 4px; }
</style>
</head>
<body>
<div id="globe"></div>
<div id="panel">
  <h1 id="ttl"></h1>
  <div class="sub" id="sub"></div>
  <div id="phases"></div>
  <svg id="chart" width="302" height="110"></svg>
  <div class="legend">
    <i style="background:#7f8ea3"></i>ISL &nbsp; <i style="background:#fff"></i>active route &nbsp; dashed = ground link<br>
    Delay = one-way propagation, recomputed from the TLEs. Keys ← → change phase.
  </div>
</div>
<script>
const DATA = __DATA__;
const COLORS = ["#ff4d4d", "#ffc23d", "#5ee06e", "#ff4dff", "#4dd2ff", "#ff9a3d", "#b18cff", "#ffffff"];

const viewer = new Cesium.Viewer("globe", {
  baseLayer: false, baseLayerPicker: false, geocoder: false, homeButton: true,
  sceneModePicker: true, navigationHelpButton: false, timeline: false, animation: false,
  infoBox: true, selectionIndicator: true, fullscreenButton: true
});
// Offline-safe base map shipped with Cesium, then satellite imagery on top
viewer.imageryLayers.add(Cesium.ImageryLayer.fromProviderAsync(
  Cesium.TileMapServiceImageryProvider.fromUrl(Cesium.buildModuleUrl("Assets/Textures/NaturalEarthII"))));
viewer.imageryLayers.addImageryProvider(new Cesium.UrlTemplateImageryProvider({
  url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
  maximumLevel: 19, credit: "Esri World Imagery"
}));

const C = (hex, a) => Cesium.Color.fromCssColorString(hex).withAlpha(a === undefined ? 1 : a);
const P = (lon, lat, h) => Cesium.Cartesian3.fromDegrees(lon, lat, h || 0);

function line(p1, p2, color, width, dashed) {
  return viewer.entities.add({ polyline: {
    positions: [P(p1[0], p1[1], p1[2]), P(p2[0], p2[1], p2[2])],
    width: width, arcType: Cesium.ArcType.NONE,
    material: dashed ? new Cesium.PolylineDashMaterialProperty({ color: color, dashLength: 12 }) : color
  }});
}

let current = 0;
function show(i) {
  current = (i + DATA.phases.length) % DATA.phases.length;
  const ph = DATA.phases[current], col = COLORS[current % COLORS.length], S = ph.sats;
  viewer.entities.removeAll();
  const onRoute = new Set(ph.path);
  const edges = new Set();
  for (let k = 0; k + 1 < ph.path.length; k++) {
    const a = ph.path[k], b = ph.path[k + 1];
    edges.add(Math.min(a, b) + "-" + Math.max(a, b));
  }
  // ISLs
  for (const [a, b] of DATA.isls) {
    if (edges.has(Math.min(a, b) + "-" + Math.max(a, b))) continue;
    line(S[a], S[b], C("#7f8ea3", 0.35), 1);
  }
  // Satellites
  S.forEach((s, j) => {
    const r = onRoute.has(j);
    viewer.entities.add({
      name: "Satellite " + j, position: P(s[0], s[1], s[2]),
      description: "Satellite " + j + "<br>lat " + s[1].toFixed(2) + "°, lon " + s[0].toFixed(2) +
                   "°<br>altitude " + (s[2] / 1000).toFixed(0) + " km",
      point: { pixelSize: r ? 13 : 7, color: r ? C(col) : C("#9fb4d0", 0.9),
               outlineColor: Cesium.Color.BLACK, outlineWidth: r ? 2 : 1 },
      label: r ? { text: "S" + j, font: "bold 13px sans-serif", fillColor: C(col),
                   outlineColor: Cesium.Color.BLACK, outlineWidth: 3, style: Cesium.LabelStyle.FILL_AND_OUTLINE,
                   pixelOffset: new Cesium.Cartesian2(0, -16) } : undefined
    });
  });
  // Ground stations
  for (const g of [DATA.src, DATA.dst]) {
    viewer.entities.add({ name: g.name, position: P(g.lon, g.lat, 0),
      point: { pixelSize: 15, color: C("#ffe14d"), outlineColor: Cesium.Color.BLACK, outlineWidth: 2 },
      label: { text: g.name, font: "bold 15px sans-serif", fillColor: C("#ffe14d"),
               outlineColor: Cesium.Color.BLACK, outlineWidth: 3, style: Cesium.LabelStyle.FILL_AND_OUTLINE,
               verticalOrigin: Cesium.VerticalOrigin.BOTTOM, pixelOffset: new Cesium.Cartesian2(0, -18) } });
  }
  // Active route
  if (ph.path.length) {
    line([DATA.src.lon, DATA.src.lat, 0], S[ph.path[0]], C(col), 3, true);
    line(S[ph.path[ph.path.length - 1]], [DATA.dst.lon, DATA.dst.lat, 0], C(col), 3, true);
    for (let k = 0; k + 1 < ph.path.length; k++) line(S[ph.path[k]], S[ph.path[k + 1]], C(col), 5);
  }
  document.querySelectorAll(".ph").forEach((b, k) => b.classList.toggle("on", k === current));
  drawChart();
}

function buildPanel() {
  document.getElementById("ttl").textContent = DATA.title;
  const m = DATA.meta;
  document.getElementById("sub").textContent = m.n_sats + " satellites · mean altitude " + m.mean_alt_km +
    " km · fstate step " + m.step + " s" + (m.offset ? " · epoch offset " + m.offset + " s" : "");
  const box = document.getElementById("phases");
  DATA.phases.forEach((ph, k) => {
    const b = document.createElement("button");
    b.className = "ph"; b.style.setProperty("--c", COLORS[k % COLORS.length]);
    b.innerHTML = "<b>Phase " + (k + 1) + "</b> · t = " + ph.t.toFixed(1) + " s<br>" +
      ph.hops + " ISL hop" + (ph.hops === 1 ? "" : "s") + " · " + ph.delay_ms.toFixed(1) + " ms · elev " +
      ph.el_src + "° / " + ph.el_dst + "°<br><span style='color:#9aa6b8'>sats " + ph.path.join(" → ") + "</span>" +
      (ph.warning ? "<br><span class='w'>⚠ " + ph.warning + "</span>" : "");
    b.onclick = () => show(k);
    box.appendChild(b);
  });
}

function drawChart() {
  const svg = document.getElementById("chart"), W = 302, H = 110, L = 34, R = 6, T = 8, B = 22;
  const t = DATA.timeline.t, d = DATA.timeline.d;
  if (!t.length) { svg.innerHTML = ""; return; }
  const t0 = t[0], t1 = Math.max(t[t.length - 1], t0 + 1);
  let d0 = Math.min(...d), d1 = Math.max(...d); const pad = (d1 - d0) * 0.15 || 1; d0 -= pad; d1 += pad;
  const x = v => L + (v - t0) / (t1 - t0) * (W - L - R), y = v => T + (1 - (v - d0) / (d1 - d0)) * (H - T - B);
  let s = "<rect x='0' y='0' width='" + W + "' height='" + H + "' fill='none'/>";
  [d0 + pad, (d0 + d1) / 2, d1 - pad].forEach(v => {
    s += "<line x1='" + L + "' x2='" + (W - R) + "' y1='" + y(v) + "' y2='" + y(v) + "' stroke='#2c3546'/>" +
         "<text x='" + (L - 4) + "' y='" + (y(v) + 4) + "' fill='#9aa6b8' font-size='10' text-anchor='end'>" + v.toFixed(1) + "</text>";
  });
  DATA.phases.forEach((ph, k) => {
    s += "<line x1='" + x(ph.t) + "' x2='" + x(ph.t) + "' y1='" + T + "' y2='" + (H - B) + "' stroke='" +
         COLORS[k % COLORS.length] + "' stroke-width='" + (k === current ? 2.5 : 1) + "' opacity='" + (k === current ? 1 : .5) + "'/>";
  });
  s += "<polyline fill='none' stroke='#e8ecf2' stroke-width='1.5' points='" +
       t.map((v, i) => x(v).toFixed(1) + "," + y(d[i]).toFixed(1)).join(" ") + "'/>";
  s += "<text x='" + L + "' y='" + (H - 6) + "' fill='#9aa6b8' font-size='10'>" + t0.toFixed(0) + " s</text>" +
       "<text x='" + (W - R) + "' y='" + (H - 6) + "' fill='#9aa6b8' font-size='10' text-anchor='end'>" + t1.toFixed(0) + " s</text>" +
       "<text x='" + ((L + W) / 2) + "' y='" + (H - 6) + "' fill='#9aa6b8' font-size='10' text-anchor='middle'>one-way delay (ms) vs time</text>";
  svg.innerHTML = s;
}

document.addEventListener("keydown", e => {
  if (e.key === "ArrowRight") show(current + 1);
  if (e.key === "ArrowLeft") show(current - 1);
});

buildPanel();
show(0);
const mid = { lon: (DATA.src.lon + DATA.dst.lon) / 2, lat: Math.min(75, (DATA.src.lat + DATA.dst.lat) / 2 + 12) };
viewer.camera.setView({ destination: Cesium.Cartesian3.fromDegrees(mid.lon, mid.lat, 9.0e6) });
</script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
